package com.rhcsoft.spring.task.pool.TaskPoolDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskPoolDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
