package com.rhcsoft.spring.task.pool.TaskPoolDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskPoolDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskPoolDemoApplication.class, args);
	}

}
